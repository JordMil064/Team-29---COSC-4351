<?php
session_start();

header("Location: mainmenu.php");
setcookie("username", " ");
?>
